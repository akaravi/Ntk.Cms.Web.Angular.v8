var galleryFilterOptions = {gutterPixels: 3,};
var filterizr = new Filterizr('.gallery-filter', galleryFilterOptions);
