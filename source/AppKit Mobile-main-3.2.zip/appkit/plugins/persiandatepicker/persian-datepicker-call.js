$('.p-date').persianDatepicker({
  initialValueType: 'persian',
  format: 'L' 
});